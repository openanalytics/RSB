# Test of Reading Extra Properties from configuration.txt File
# 
# Author: Tobias Verbeke
####################################################################################

require(properties)
properties <- read.properties("configuration.txt")
reportAuthor <- properties$reportAuthor # NULL if not specified in configuration.txt

if(is.null(reportAuthor))
  stop("No 'reportAuthor' field in 'configuration.txt'")

pdf(file = "reportAuthor.pdf")
plot(rnorm(123), main = paste("Plot for ", reportAuthor, sep = ""))
dev.off()
