pdf(file = "rnorm.pdf")
  plot(rnorm(234))
dev.off()
